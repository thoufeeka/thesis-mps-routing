#pragma once

#include <complex>
#include <Eigen/Eigen>
#include <random>
#include "SimpleGates.h"


bool approxEqual(double val1, double val2, double err = 1E-10);
bool approxEqual(std::complex<double> val1, std::complex<double> val2, double err = 1E-10);
bool checkUnitary(const Eigen::MatrixXcd& m);
bool checkHermitian(const Eigen::MatrixXcd& m);

bool checkGates();

bool registerMeasurementsTests();
bool SimulationTests();
bool TeleportationTests();

bool ParadoxesTests();
bool quantumAdderTests();

bool ErrorCorrectionTests();

bool GamesTests();

bool distributedTests();

bool PhaseEstimationTests();

bool DeutschJozsaTests();

bool QMLTests();

bool IsingTests();

bool VQETests();

bool MPSSimulatorTests();

bool MPOSimulatorTests();

bool DensityMatrixTests();

bool CliffordSimulatorTests();
bool CliffordExpectationValuesTests();

void ConstructPauliString(size_t nrQubits, std::string& pauliStr, std::vector<QC::Gates::AppliedGate<>>& expGates);
void ConstructCircuit(size_t nrQubits, std::vector<int>& gates, std::vector<size_t>& qubits1, std::vector<size_t>& qubits2, std::uniform_int_distribution<int>& gateDistr, std::uniform_int_distribution<int>& qubitDistr);
std::shared_ptr<QC::Gates::QuantumGateWithOp<>> GetGate(int code, double param = 0.0);

bool TestPauliPropagator();

bool TestExtStabilizer();

bool TestPathIntegral();

bool tests(int option);

#ifndef TESTS_CPP_

extern std::random_device rd;
extern std::mt19937 gen;

extern std::bernoulli_distribution dist_bool;
extern std::uniform_real_distribution<double> dist_ampl;

#endif
