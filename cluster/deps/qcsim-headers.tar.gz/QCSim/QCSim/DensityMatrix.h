#pragma once

#include "QubitRegisterCalculator.h"
#include "QubitRegister.h"
#include "SimpleGates.h"

#include <random>
#include <vector>
#include <complex>
#include <chrono>
#include <cctype>
#include <cassert>
#include <cstdint>
#include <cmath>
#include <limits>
#include <stdexcept>
#include <string>
#include <utility>
#include <algorithm>
#include <memory>
#include <map>
#include <set>
#include <unordered_map>

// A density-matrix quantum computing simulator.
//
// The state is stored as a rho = 2^n x 2^n complex matrix (MatrixClass), not as a vectorized
// super-operator. Unitary gates are applied as rho' = U rho U^dagger by reusing the exact same
// bit-mask gate kernels from QubitRegisterCalculator, but instead of building a full register and
// copying data back and forth, the kernels are fed directly with the columns and the rows of rho
// (Eigen block expressions used as fake 'registers').
//
// The left multiplication U rho is done by applying U to every column (the ket index); the right
// multiplication by U^dagger is done by applying the (elementwise) conjugated small operator to
// every row (the bra index). Only the small operator matrix is conjugated, never the big rho, and
// the calculators are held as member objects instead of being inherited from.
//
// Qubits are numbered from right to left, starting with zero (same convention as QubitRegister).

namespace QC {

	template<class VectorClass = Eigen::VectorXcd, class MatrixClass = Eigen::MatrixXcd>
	class DensityMatrix
	{
	public:
		using GateClass = Gates::QuantumGateWithOp<MatrixClass>;

		// whatever rho.col(0) / rho.row(0) return - the Eigen block expressions used as fake 'registers'
		using ColXpr = decltype(std::declval<MatrixClass&>().col(0));
		using RowXpr = decltype(std::declval<MatrixClass&>().row(0));

		// two calculators, one instantiated for the column blocks, one for the row blocks
		using ColCalculator = QubitRegisterCalculator<ColXpr, MatrixClass>;
		using RowCalculator = QubitRegisterCalculator<RowXpr, MatrixClass>;

		DensityMatrix(size_t N = 3, unsigned int addseed = 0)
			: NrQubits(N), NrBasisStates(CheckedBasisStateCount(N)),
			rho(MatrixClass::Zero(NrBasisStates, NrBasisStates)),
			target(MatrixClass::Zero(NrBasisStates, NrBasisStates)),
			uniformZeroOne(0, 1)
		{
			if (addseed == 0)
			{
				std::random_device rdl;
				addseed = rdl();
			}

			const uint64_t timeSeed = std::chrono::high_resolution_clock::now().time_since_epoch().count() + addseed;
			std::seed_seq seed{ uint32_t(timeSeed & 0xffffffff), uint32_t(timeSeed >> 32) };
			rng.seed(seed);

			rho(0, 0) = 1.; // |0...0><0...0|
		}

		size_t getNrQubits() const { return NrQubits; }
		size_t getNrBasisStates() const { return NrBasisStates; }

		// Allows simulations and statistical tests to be reproduced exactly.
		void SetRandomSeed(uint64_t seed) { rng.seed(seed); }

		const MatrixClass& getDensityMatrix() const { return rho; }

		void Clear()
		{
			rho.setZero();
		}

		void setToBasisState(size_t State)
		{
			if (State >= NrBasisStates)
				throw std::invalid_argument("Basis state is outside the register");

			rho.setZero();
			rho(State, State) = 1.;
		}

		void Reset()
		{
			setToBasisState(0);
		}

		void SaveState()
		{
			savedStateStorage = rho;
		}

		void RestoreState()
		{
			if (savedStateStorage.size() == 0) return;

			rho = savedStateStorage;
		}

		void RestoreStateDestructive()
		{
			if (savedStateStorage.size() == 0) return;

			rho.swap(savedStateStorage);
			savedStateStorage.resize(0, 0);
		}

		std::unique_ptr<DensityMatrix<VectorClass, MatrixClass>> Clone() const
		{
			auto sim = std::make_unique<DensityMatrix<VectorClass, MatrixClass>>(NrQubits);
			sim->rho = rho;
			sim->savedStateStorage = savedStateStorage;
			sim->rng = rng;
			sim->uniformZeroOne = uniformZeroOne;

			return sim;
		}

		// Initialize rho = |psi><psi| from a statevector, normalizing any finite non-zero input.
		// This is very convenient for comparing against the statevector simulator.
		void setFromStatevector(const VectorClass& psi)
		{
			if (psi.size() < 0 || static_cast<size_t>(psi.size()) != NrBasisStates)
				throw std::invalid_argument("Statevector dimension does not match the register");
			if (!psi.allFinite())
				throw std::invalid_argument("Statevector contains a non-finite value");

			const double normSquared = psi.squaredNorm();
			if (!std::isfinite(normSquared) || normSquared <= 1E-20)
				throw std::invalid_argument("Statevector must have a finite non-zero norm");

			rho = (psi * psi.adjoint()) / normSquared;
		}

		// set the whole density matrix directly (the caller is responsible for it being a valid state:
		// Hermitian, positive semidefinite and unit trace)
		void setDensityMatrix(const MatrixClass& newRho)
		{
			if (newRho.rows() < 0 || newRho.cols() < 0 ||
				static_cast<size_t>(newRho.rows()) != NrBasisStates || static_cast<size_t>(newRho.cols()) != NrBasisStates)
				throw std::invalid_argument("Density matrix dimensions do not match the register");

			rho = newRho;
		}

		// set the state to a classical mixture of computational basis states: rho = sum_k p_k |s_k><s_k|
		// the weights are normalized to sum to 1 (negative or zero weights are ignored)
		void setToMixtureOfBasisStates(const std::vector<std::pair<size_t, double>>& mixture)
		{
			double total = 0.;
			for (const auto& [state, weight] : mixture)
			{
				if (!std::isfinite(weight))
					throw std::invalid_argument("Mixture weights must be finite");
				if (weight > 0. && state < NrBasisStates) total += weight;
			}

			if (!std::isfinite(total) || total <= 0.)
				throw std::invalid_argument("Mixture must contain at least one valid positive weight");

			rho.setZero();

			for (const auto& [state, weight] : mixture)
				if (weight > 0. && state < NrBasisStates)
					rho(static_cast<Eigen::Index>(state), static_cast<Eigen::Index>(state)) += weight / total;
		}

		// rho' = U rho U^dagger
		void ApplyGate(const GateClass& gate, size_t qubit, size_t controllingQubit1 = 0, size_t controllingQubit2 = 0)
		{
			const size_t gateQubits = ValidateGateAndQubits(gate, qubit, controllingQubit1, controllingQubit2);
			const MatrixClass& U = gate.getRawOperatorMatrix();
			const MatrixClass Uconj = U.conjugate(); // small, cheap to conjugate

			// rho <- U rho : apply U to every column (the ket index)
			ApplyGateToColumns(gate, U, gateQubits, qubit, controllingQubit1, controllingQubit2);

			// rho <- (U rho) U^dagger : right multiplication by U^dagger is applying the conjugated
			// small operator to every row (the bra index). Only the small operator was conjugated.
			ApplyGateToRows(gate, Uconj, gateQubits, qubit, controllingQubit1, controllingQubit2);
		}

		void ApplyGate(const Gates::AppliedGate<MatrixClass>& gate)
		{
			ApplyGate(gate, gate.getQubit1(), gate.getQubit2(), gate.getQubit3());
		}

		void ApplyGates(const std::vector<Gates::AppliedGate<MatrixClass>>& gates)
		{
			for (const auto& gate : gates)
				ApplyGate(gate);
		}

		// Generic completely positive trace preserving channel: rho' = sum_k E_k rho E_k^dagger.
		// The completeness relation sum_k E_k^dagger E_k = I is validated before changing the state.
		// The Kraus operators are small matrices (2x2 for a single qubit, 4x4 for two qubits) acting
		// on the given qubit(s). This is the fundamental non-unitary operation; a unitary gate is just
		// the special case of a single Kraus operator E_0 = U.
		void ApplyChannel(const std::vector<MatrixClass>& kraus, size_t qubit, size_t controllingQubit1 = 0)
		{
			if (kraus.empty())
				throw std::invalid_argument("A channel must contain at least one Kraus operator");

			const size_t gateQubits = GetOperatorQubits(kraus.front(), 2);
			ValidateQubits(gateQubits, qubit, controllingQubit1, 0);
			const Eigen::Index operatorDimension = kraus.front().rows();
			MatrixClass completeness = MatrixClass::Zero(operatorDimension, operatorDimension);
			for (const auto& E : kraus)
			{
				if (GetOperatorQubits(E, 2) != gateQubits || E.rows() != operatorDimension)
					throw std::invalid_argument("All Kraus operators must have the same dimensions");
				if (!E.allFinite())
					throw std::invalid_argument("Kraus operators must contain only finite values");
				completeness.noalias() += E.adjoint() * E;
			}

			const MatrixClass identity = MatrixClass::Identity(operatorDimension, operatorDimension);
			const double completenessTolerance = 1E-10 * std::max<Eigen::Index>(1, operatorDimension);
			if ((completeness - identity).norm() > completenessTolerance)
				throw std::invalid_argument("Kraus operators do not define a trace-preserving channel");

			const MatrixClass original = rho;
			MatrixClass acc = MatrixClass::Zero(NrBasisStates, NrBasisStates);

			for (const auto& E : kraus)
			{
				const Gates::AppliedGate<MatrixClass> gate(E);
				const MatrixClass Econj = E.conjugate();

				rho = original;

				// rho <- E_k rho E_k^dagger (left mult on columns, right mult on rows with the
				// conjugated small operator - the big matrix is never adjointed)
				ApplyGateToColumns(gate, E, gateQubits, qubit, controllingQubit1, 0);
				ApplyGateToRows(gate, Econj, gateQubits, qubit, controllingQubit1, 0);

				acc += rho;
			}

			rho.swap(acc);
		}

		// ---- predefined single qubit noise channels ----

		// bit flip: rho' = (1 - p) rho + p X rho X
		void ApplyBitFlipNoise(size_t qubit, double p)
		{
			ValidateProbability(p, "Bit-flip probability");
			ApplyChannel({ std::sqrt(1. - p) * PauliI(), std::sqrt(p) * PauliX() }, qubit);
		}

		// phase flip: rho' = (1 - p) rho + p Z rho Z
		void ApplyPhaseFlipNoise(size_t qubit, double p)
		{
			ValidateProbability(p, "Phase-flip probability");
			ApplyChannel({ std::sqrt(1. - p) * PauliI(), std::sqrt(p) * PauliZ() }, qubit);
		}

		// depolarizing: rho' = (1 - p) rho + p/3 (X rho X + Y rho Y + Z rho Z)
		void ApplyDepolarizingNoise(size_t qubit, double p)
		{
			ValidateProbability(p, "Depolarizing probability");
			const double s = std::sqrt(p / 3.);
			ApplyChannel({ std::sqrt(1. - p) * PauliI(), s * PauliX(), s * PauliY(), s * PauliZ() }, qubit);
		}

		// amplitude damping (|1> -> |0> relaxation with probability gamma)
		void ApplyAmplitudeDamping(size_t qubit, double gamma)
		{
			ValidateProbability(gamma, "Amplitude-damping probability");
			MatrixClass E0 = MatrixClass::Zero(2, 2);
			E0(0, 0) = 1.;
			E0(1, 1) = std::sqrt(1. - gamma);

			MatrixClass E1 = MatrixClass::Zero(2, 2);
			E1(0, 1) = std::sqrt(gamma);

			ApplyChannel({ E0, E1 }, qubit);
		}

		// phase damping / dephasing, suppresses the off diagonal coherences by lambda = sqrt(1 - gamma)
		void ApplyPhaseDamping(size_t qubit, double gamma)
		{
			ValidateProbability(gamma, "Phase-damping probability");
			MatrixClass E0 = MatrixClass::Zero(2, 2);
			E0(0, 0) = 1.;
			E0(1, 1) = std::sqrt(1. - gamma);

			MatrixClass E1 = MatrixClass::Zero(2, 2);
			E1(1, 1) = std::sqrt(gamma);

			ApplyChannel({ E0, E1 }, qubit);
		}

		// reset a qubit to |0>: E0 = |0><0|, E1 = |0><1|
		void ApplyReset(size_t qubit)
		{
			MatrixClass E0 = MatrixClass::Zero(2, 2);
			E0(0, 0) = 1.;

			MatrixClass E1 = MatrixClass::Zero(2, 2);
			E1(0, 1) = 1.;

			ApplyChannel({ E0, E1 }, qubit);
		}

		// ---- measurement ----

		double GetQubitProbability(size_t qubit) const
		{
			ValidateQubit(qubit);
			const size_t mask = 1ULL << qubit;

			double p1 = 0;
			for (size_t i = 0; i < NrBasisStates; ++i)
				if (i & mask)
					p1 += rho(i, i).real();

			return p1;
		}

		// sample a computational basis outcome for a single qubit and collapse
		size_t MeasureQubit(size_t qubit)
		{
			ValidateQubit(qubit);
			const size_t mask = 1ULL << qubit;

			double p0 = 0;
			double p1 = 0;
			for (size_t i = 0; i < NrBasisStates; ++i)
			{
				const double population = ValidatedPopulation(i);
				if ((i & mask) == 0) p0 += population;
				else p1 += population;
			}

			const double total = p0 + p1;
			if (!std::isfinite(total) || total <= 1E-20)
				throw std::domain_error("Cannot measure a state with no probability mass");

			const double r = std::min(uniformZeroOne(rng) * total, std::nextafter(total, 0.));
			const size_t result = (r < p0) ? 0 : 1;
			const double pm = (result == 0) ? p0 : p1;

			CollapseQubit(qubit, result, pm);

			return result;
		}

		// non selective measurement of a qubit: rho' = P0 rho P0 + P1 rho P1
		// destroys the coherence between the two measurement sectors but keeps the populations
		void DephaseMeasure(size_t qubit)
		{
			ValidateQubit(qubit);
			const size_t mask = 1ULL << qubit;

			for (size_t i = 0; i < NrBasisStates; ++i)
				for (size_t j = 0; j < NrBasisStates; ++j)
					if (((i & mask) == 0) != ((j & mask) == 0))
						rho(i, j) = 0;
		}

		// sample a full computational basis outcome from the diagonal populations without collapsing
		// the state - useful for repeated sampling that avoids re-executing the circuit each time.
		// The returned value is the measured basis state (bit k corresponds to qubit k).
		size_t MeasureNoCollapse()
		{
			std::vector<double> cumulativeProbabilities;
			const double total = BuildCumulativeProbabilities(cumulativeProbabilities);
			const double probability = std::min(uniformZeroOne(rng) * total, std::nextafter(total, 0.));
			const auto it = std::upper_bound(cumulativeProbabilities.begin(), cumulativeProbabilities.end(), probability);
			return it == cumulativeProbabilities.end()
				? NrBasisStates - 1
				: static_cast<size_t>(it - cumulativeProbabilities.begin());
		}

		// sample a subset of qubits from the diagonal populations without collapsing the state.
		// Internally a full basis outcome is drawn from the exact marginal distribution and only the
		// requested qubits are reported. The map keys are the qubit indices, the values the outcomes.
		std::unordered_map<size_t, bool> MeasureNoCollapse(const std::set<size_t>& qubits)
		{
			std::unordered_map<size_t, bool> res;
			if (qubits.empty()) return res;

			for (const size_t qubit : qubits)
				ValidateQubit(qubit);

			const size_t state = MeasureNoCollapse();
			for (const size_t qubit : qubits)
				res[qubit] = (state & (1ULL << qubit)) != 0;

			return res;
		}

		// repeatedly sample the full computational basis distribution without collapsing the state.
		// The cumulative distribution is built once, then reused for every shot.
		std::map<size_t, size_t> RepeatedMeasure(size_t nrTimes = 1000)
		{
			return RepeatedMeasureImpl<std::map<size_t, size_t>>(0, NrBasisStates - 1, nrTimes);
		}

		std::unordered_map<size_t, size_t> RepeatedMeasureUnordered(size_t nrTimes = 1000)
		{
			return RepeatedMeasureImpl<std::unordered_map<size_t, size_t>>(0, NrBasisStates - 1, nrTimes);
		}

		// repeatedly sample a contiguous subregister. The returned outcomes are packed so firstQubit
		// becomes bit zero, matching the statevector simulator's RepeatedMeasure overloads.
		std::map<size_t, size_t> RepeatedMeasure(size_t firstQubit, size_t secondQubit, size_t nrTimes = 1000)
		{
			ValidateMeasurementRange(firstQubit, secondQubit);
			const size_t firstPartMask = (1ULL << firstQubit) - 1;
			const size_t measuredPartMask = (1ULL << (secondQubit + 1)) - 1 - firstPartMask;
			return RepeatedMeasureImpl<std::map<size_t, size_t>>(firstQubit, measuredPartMask, nrTimes);
		}

		std::unordered_map<size_t, size_t> RepeatedMeasureUnordered(size_t firstQubit, size_t secondQubit, size_t nrTimes = 1000)
		{
			ValidateMeasurementRange(firstQubit, secondQubit);
			const size_t firstPartMask = (1ULL << firstQubit) - 1;
			const size_t measuredPartMask = (1ULL << (secondQubit + 1)) - 1 - firstPartMask;
			return RepeatedMeasureImpl<std::unordered_map<size_t, size_t>>(firstQubit, measuredPartMask, nrTimes);
		}

		// ---- diagnostics ----

		std::complex<double> Trace() const
		{
			return rho.trace();
		}

		// Tr(rho^2), equals 1 for a pure state, < 1 for a mixed one
		double Purity() const
		{
			// For a Hermitian density matrix Tr(rho^2) is its squared Frobenius norm.
			return rho.squaredNorm();
		}

		bool IsHermitian(double eps = 1E-10) const
		{
			return (rho - rho.adjoint()).norm() < eps;
		}

		double getBasisStateProbability(size_t State) const
		{
			if (State >= NrBasisStates) return 0;

			return rho(State, State).real();
		}

		// <O> = Tr(rho O), the caller should ensure O is Hermitian and take the real part
		std::complex<double> ExpectationValue(const MatrixClass& O) const
		{
			if (O.rows() != rho.rows() || O.cols() != rho.cols())
				throw std::invalid_argument("Observable dimensions do not match the density matrix");

			return rho.cwiseProduct(O.transpose()).sum();
		}

		// <P> = Tr(rho P) for a Pauli string P = (x) P_i, where character i of the string is
		// the single qubit Pauli ('I', 'X', 'Y' or 'Z') acting on qubit i (qubit 0 is the
		// rightmost / least significant bit, character 0 in the string).
		//
		// This avoids the full 2^N x 2^N matrix product used by the operator overload: a single
		// qubit Pauli P_i maps a basis state |i> to a phase times a single other basis state, so
		// P|k> = phase(k) |k ^ flipMask> and Tr(rho P) = sum_k phase(k) rho(k ^ flipMask, k),
		// which only touches 2^N entries of rho.
		std::complex<double> ExpectationValue(const std::string& pauliString) const
		{
			if (pauliString.size() != NrQubits)
				throw std::invalid_argument("Pauli string length must match the number of qubits");

			size_t flipMask = 0; // qubits where X or Y act (the bit flipped by P)
			size_t signMask = 0; // qubits where Y or Z act (contribute a (-1)^bit sign)
			size_t yCount = 0;   // number of Y factors (each contributes a factor of i)

			for (size_t i = 0; i < NrQubits; ++i)
			{
				const size_t bit = 1ULL << i;
				switch (toupper(static_cast<unsigned char>(pauliString[i])))
				{
				case 'I':
					break;
				case 'X':
					flipMask |= bit;
					break;
				case 'Y':
					flipMask |= bit;
					signMask |= bit;
					++yCount;
					break;
				case 'Z':
					signMask |= bit;
					break;
				default:
					throw std::invalid_argument("Invalid operator in the Pauli string");
				}
			}

			std::complex<double> result = 0.;
			for (size_t k = 0; k < NrBasisStates; ++k)
			{
				// parity of the sign-contributing bits set in k
				size_t s = signMask & k;
				bool negative = false;
				while (s)
				{
					negative = !negative;
					s &= s - 1;
				}

				const std::complex<double> term = rho(k, k ^ flipMask);
				result += negative ? -term : term;
			}

			// each Y contributed a factor of i, fold i^yCount in at the end
			static const std::complex<double> iPow[4] = { {1., 0.}, {0., 1.}, {-1., 0.}, {0., -1.} };
			result *= iPow[yCount & 3];

			return result;
		}

	protected:
		template<class Measurements>
		Measurements RepeatedMeasureImpl(size_t firstQubit, size_t measuredPartMask, size_t nrTimes)
		{
			Measurements measurements;
			if (nrTimes == 0) return measurements;

			if (nrTimes == 1)
			{
				const size_t state = MeasureNoCollapse();
				++measurements[(state & measuredPartMask) >> firstQubit];
				return measurements;
			}

			std::vector<double> cumulativeProbabilities;
			const double total = BuildCumulativeProbabilities(cumulativeProbabilities);

			for (size_t shot = 0; shot < nrTimes; ++shot)
			{
				const double probability = std::min(uniformZeroOne(rng) * total, std::nextafter(total, 0.));
				const auto it = std::upper_bound(cumulativeProbabilities.begin(), cumulativeProbabilities.end(), probability);
				const size_t state = it == cumulativeProbabilities.end()
					? NrBasisStates - 1
					: static_cast<size_t>(it - cumulativeProbabilities.begin());
				++measurements[(state & measuredPartMask) >> firstQubit];
			}

			return measurements;
		}

		static size_t CheckedBasisStateCount(size_t nrQubits)
		{
			if (nrQubits == 0)
				throw std::invalid_argument("Qubit number must be positive");
			if (nrQubits >= std::numeric_limits<size_t>::digits)
				throw std::invalid_argument("Qubit number is too large for basis-state indexing");

			const size_t nrBasisStates = size_t{ 1 } << nrQubits;
			if (nrBasisStates > static_cast<size_t>(std::numeric_limits<Eigen::Index>::max()))
				throw std::length_error("Register dimension exceeds Eigen's index range");
			const size_t maxElements = std::numeric_limits<size_t>::max() / sizeof(typename MatrixClass::Scalar);
			if (nrBasisStates > maxElements / nrBasisStates)
				throw std::length_error("Density-matrix storage size overflows size_t");

			return nrBasisStates;
		}

		static size_t GetOperatorQubits(const MatrixClass& op, size_t maxQubits = 3)
		{
			if (op.rows() <= 0 || op.cols() <= 0 || op.rows() != op.cols())
				throw std::invalid_argument("Operator must be a non-empty square matrix");

			const size_t dimension = static_cast<size_t>(op.rows());
			if ((dimension & (dimension - 1)) != 0)
				throw std::invalid_argument("Operator dimension must be a power of two");

			size_t qubits = 0;
			for (size_t value = dimension; value > 1; value >>= 1) ++qubits;
			if (qubits == 0 || qubits > maxQubits)
				throw std::invalid_argument("Operator acts on an unsupported number of qubits");

			return qubits;
		}

		size_t ValidateGateAndQubits(const GateClass& gate, size_t qubit, size_t controllingQubit1, size_t controllingQubit2) const
		{
			const MatrixClass& op = gate.getRawOperatorMatrix();
			const size_t gateQubits = GetOperatorQubits(op);
			if (gate.getQubitsNumber() != gateQubits)
				throw std::invalid_argument("Gate arity does not match its operator matrix");
			if (!op.allFinite())
				throw std::invalid_argument("Gate operator contains a non-finite value");

			ValidateQubits(gateQubits, qubit, controllingQubit1, controllingQubit2);
			return gateQubits;
		}

		void ValidateQubits(size_t gateQubits, size_t qubit, size_t controllingQubit1, size_t controllingQubit2) const
		{
			ValidateQubit(qubit);
			if (gateQubits >= 2)
			{
				ValidateQubit(controllingQubit1);
				if (qubit == controllingQubit1)
					throw std::invalid_argument("Gate qubits must be distinct");
			}
			if (gateQubits == 3)
			{
				ValidateQubit(controllingQubit2);
				if (qubit == controllingQubit2 || controllingQubit1 == controllingQubit2)
					throw std::invalid_argument("Gate qubits must be distinct");
			}
		}

		void ValidateQubit(size_t qubit) const
		{
			if (qubit >= NrQubits)
				throw std::invalid_argument("Qubit number is outside the register");
		}

		void ValidateMeasurementRange(size_t firstQubit, size_t secondQubit) const
		{
			if (firstQubit > secondQubit)
				throw std::invalid_argument("First measured qubit must not exceed the second");
			ValidateQubit(secondQubit);
		}

		static void ValidateProbability(double probability, const char* name)
		{
			if (!std::isfinite(probability) || probability < 0. || probability > 1.)
				throw std::invalid_argument(std::string(name) + " must be finite and in [0, 1]");
		}

		double ValidatedPopulation(size_t state) const
		{
			const auto diagonal = rho(state, state);
			const double population = diagonal.real();
			if (!std::isfinite(population) || !std::isfinite(diagonal.imag()) || std::abs(diagonal.imag()) > 1E-10)
				throw std::domain_error("Density-matrix populations must be finite and real");
			if (population < -1E-12)
				throw std::domain_error("Density-matrix populations must be non-negative");
			return std::max(0., population);
		}

		double BuildCumulativeProbabilities(std::vector<double>& cumulativeProbabilities) const
		{
			cumulativeProbabilities.resize(NrBasisStates);
			double cumulativeProbability = 0.;
			for (size_t state = 0; state < NrBasisStates; ++state)
			{
				cumulativeProbability += ValidatedPopulation(state);
				cumulativeProbabilities[state] = cumulativeProbability;
			}

			if (!std::isfinite(cumulativeProbability) || cumulativeProbability <= 1E-20)
				throw std::domain_error("Cannot sample a state with no probability mass");
			return cumulativeProbability;
		}

		// applies a small gate to every column of rho (the ket index). Each column is a fake 'register'
		// (an Eigen block expression) fed directly to the reused QubitRegisterCalculator kernels; results
		// go in place or into the matching column of the target buffer, which is then swapped in - so no
		// per column temporaries and no copies back and forth.
		void ApplyGateToColumns(const GateClass& gate, const MatrixClass& gateMatrix, size_t gateQubits, size_t qubit, size_t controllingQubit1, size_t controllingQubit2)
		{
			const size_t qubitBit = 1ULL << qubit;

			bool swapStorage = true;
			for (size_t col = 0; col < NrBasisStates; ++col)
			{
				ColXpr src = rho.col(col);
				ColXpr dst = target.col(col);

				swapStorage = true;
				if (gateQubits == 1)
					colCalculator.ApplyOneQubitGate(gate, src, dst, gateMatrix, qubitBit, NrBasisStates, swapStorage);
				else if (gateQubits == 2)
				{
					const size_t ctrlQubitBit = 1ULL << controllingQubit1;
					colCalculator.ApplyTwoQubitsGate(gate, src, dst, gateMatrix, qubitBit, ctrlQubitBit, NrBasisStates, swapStorage);
				}
				else
				{
					const size_t qubitBit2 = 1ULL << controllingQubit1;
					const size_t ctrlQubitBit = 1ULL << controllingQubit2;
					colCalculator.ApplyThreeQubitsGate(gate, src, dst, gateMatrix, qubitBit, qubitBit2, ctrlQubitBit, NrBasisStates, swapStorage);
				}
			}

			if (swapStorage) rho.swap(target); // the results ended up in the target, make it the new rho
		}

		// applies U^dagger from the right (the bra index) by applying the conjugated small operator to
		// every row of rho. The passed gateMatrix is already the elementwise conjugate, so the kernels
		// that read the matrix (generic / diagonal / antidiagonal / controlled) are directly correct.
		// The hardcoded iSwap / iSwapDag kernels ignore the matrix, so their roles are swapped here to
		// realize the conjugate (iSwap^dagger = iSwapDag); swap gates are self conjugate.
		void ApplyGateToRows(const GateClass& gate, const MatrixClass& gateMatrix, size_t gateQubits, size_t qubit, size_t controllingQubit1, size_t controllingQubit2)
		{
			const size_t qubitBit = 1ULL << qubit;

			const GateClass* dispatchGate = &gate;
			static const Gates::iSwapGate<MatrixClass> iswap;
			static const Gates::iSwapDagGate<MatrixClass> iswapDag;
			if (gateQubits == 2)
			{
				if (gate.IsISwapGate()) dispatchGate = &iswapDag;
				else if (gate.IsISwapDagGate()) dispatchGate = &iswap;
			}

			bool swapStorage = true;
			for (size_t row = 0; row < NrBasisStates; ++row)
			{
				RowXpr src = rho.row(row);
				RowXpr dst = target.row(row);

				swapStorage = true;
				if (gateQubits == 1)
					rowCalculator.ApplyOneQubitGate(*dispatchGate, src, dst, gateMatrix, qubitBit, NrBasisStates, swapStorage);
				else if (gateQubits == 2)
				{
					const size_t ctrlQubitBit = 1ULL << controllingQubit1;
					rowCalculator.ApplyTwoQubitsGate(*dispatchGate, src, dst, gateMatrix, qubitBit, ctrlQubitBit, NrBasisStates, swapStorage);
				}
				else
				{
					const size_t qubitBit2 = 1ULL << controllingQubit1;
					const size_t ctrlQubitBit = 1ULL << controllingQubit2;
					rowCalculator.ApplyThreeQubitsGate(*dispatchGate, src, dst, gateMatrix, qubitBit, qubitBit2, ctrlQubitBit, NrBasisStates, swapStorage);
				}
			}

			if (swapStorage) rho.swap(target);
		}

		void CollapseQubit(size_t qubit, size_t result, double pm)
		{
			const size_t mask = 1ULL << qubit;
			const double invpm = (pm > 1E-20) ? 1. / pm : 0.;

			for (size_t i = 0; i < NrBasisStates; ++i)
			{
				const size_t bi = (i & mask) ? 1 : 0;
				for (size_t j = 0; j < NrBasisStates; ++j)
				{
					const size_t bj = (j & mask) ? 1 : 0;
					if (bi != result || bj != result)
						rho(i, j) = 0;
					else
						rho(i, j) *= invpm;
				}
			}
		}

		static MatrixClass PauliI()
		{
			MatrixClass m = MatrixClass::Identity(2, 2);
			return m;
		}

		static MatrixClass PauliX()
		{
			MatrixClass m = MatrixClass::Zero(2, 2);
			m(0, 1) = 1.;
			m(1, 0) = 1.;
			return m;
		}

		static MatrixClass PauliY()
		{
			MatrixClass m = MatrixClass::Zero(2, 2);
			m(0, 1) = std::complex<double>(0, -1);
			m(1, 0) = std::complex<double>(0, 1);
			return m;
		}

		static MatrixClass PauliZ()
		{
			MatrixClass m = MatrixClass::Zero(2, 2);
			m(0, 0) = 1.;
			m(1, 1) = -1.;
			return m;
		}

		size_t NrQubits;
		size_t NrBasisStates;

		MatrixClass rho;
		MatrixClass target; // reused scratch buffer, swapped in place of rho when a kernel needs a target
		MatrixClass savedStateStorage;

		// stateless calculators held as member objects (composition instead of inheritance)
		ColCalculator colCalculator;
		RowCalculator rowCalculator;

		std::mt19937_64 rng;
		std::uniform_real_distribution<double> uniformZeroOne;
	};

}
